TGUI - Texus's Graphical User Interface
=======================================

[![Build Status](https://travis-ci.org/texus/TGUI.svg?branch=v0.6)](https://travis-ci.org/texus/TGUI)

In one line: TGUI is an easy to use, cross-platform, c++ GUI for SFML.

For more information, take a look at the website (https://tgui.eu).



Download
--------

You can download the latest release on Github (https://github.com/texus/TGUI).

This download contains the latest development snapshot of TGUI v0.6.



Tutorials
---------

Tutorials can be found on my site (https://tgui.eu/tutorials/v0.6/).

You can also find example code there (https://tgui.eu/example-code/v0.6/).



About me
--------

Name:     Bruno Van de Velde

E-mail:   vdv_b@tgui.eu

Location: Belgium

