#include "OOCore.hpp"

print Print;
input Input;